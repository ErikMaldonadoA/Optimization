// OPTIMIZACION


#include <iostream>
#include <math.h>
#include <vector>
#include <time.h>
#include <fstream>
#include<string>
using namespace std;


// Inicio del programa

int main ()
{
    
   
    
    cout<<"<<<<<TSP CON RECOCIDO SIMULADO>>>>>"<<endl<<endl;

    int n,i,j;
    
    string nombre_del_archivo = "matriz1.txt"; //cambiar nombre del archivo
    ifstream datos_matriz; 
    datos_matriz.open(nombre_del_archivo.c_str());
    if (datos_matriz.fail()) {
       cout << "\nNo se pudo abrir el archivo " << nombre_del_archivo;
       cout << "\nPresione ENTER para terminar" << endl;
       cin.get();
       exit(1); 
    }
 datos_matriz >>n;
 int longitud_segmento,distancias[n][n];
 char A;
    
  for (i=0;i<n;i++){
       for (j=0;j<n;j++){
          datos_matriz >> longitud_segmento >> A;
          distancias[i][j] = longitud_segmento;
       }
    }
    datos_matriz.close();   
 
 
 for (i=0;i<n;i++){
       for (j=0;j<n;j++)
       {
         
          cout<<distancias[i][j]<<"\t";
       }
      cout<<"\n\n";
    }
    
    
     long double s, s1, t, deltas, deltae, alpha, k,x;
    vector <int> vector1;
    int nodo,tam, sw, al1, al2, vector2[n],d;
    double es, es1;
   
    
    tam=vector1.size();
    srand(time(0));
    
    
 for(i=0;i<n;i++)
 {
    vector1.insert(vector1.end(),i);
}  
    random_shuffle(vector1.begin(),vector1.end());
    

    t=1000000000;
    k=0.9999;
    d=5;
      
    
    while(t>1)
    {
        for (i=0;i<d;i++)
        {
        do{
        al1=(0+rand()%n);
        al2=(0+rand()%n);
        }while(al1==al2);
        
        tam=vector1.size();
   
        for (i=0;i<n;i++)
        {
        vector2[i]=vector1[i];
        }
        
        
        vector2[al1]=vector1[al2];
        vector2[al2]=vector1[al1];
        
        es=0;
        es1=0;
       
        for (i=0;i<n-1;i++){
        
        //cout<<vector1[i]+1<<"\t"<<vector1[i+1]+1<<endl;
        es=es+distancias[vector1[i]][vector1[i+1]];
        es1=es1+distancias[vector2[i]][vector2[i+1]];
        //cout<<"act="<<es<<"\tnew="<<es1<<endl;
        //system("Pause");
        //es=es+pow(pow((M[vector1[i]][1]-M[vector1[i-1]][1]),2)+ pow((M[vector1[i]][2]-M[vector1[i-1]][2]),2),0.5);

        //es1=es1+pow(pow(M[vector2[i]][1]-M[vector2[i-1]][1],2)+pow(M[vector2[i]][2]-M[vector2[i-1]][2],2),0.5);
       
        }
        
        deltae=es1-es;
        x=es;
        
        if (deltae<=0){
         
        for (i=0;i<n;i++)
        vector1[i]=vector2[i];
        
        x=es1;
        
        }
        else{
             
        alpha=(0+rand()%100);
        alpha=alpha/100;
             
        if (alpha<=exp(-deltae/t)){
           
           for (i=0;i<n;i++)
           vector1[i]=vector2[i];
        
             x=es1;
             }
         }
         }
        t=t*k;
      
  
        
    }
    
    
    
    cout<<"El valor de minimo de la distancia es = "<<x<<" y la ruta es: "<<endl<<endl;
    cout<<"Ruta: (";
    for (i=0;i<n;i++)
    cout<<1+vector1[i]<<",";
    cout<<")";
    
    cout<<endl;
    
    //Para mantener la ventana abierta 
    cin.ignore (256,'\n');
    cout << "Presione ENTER para terminar" << endl;
    cin.get();
    
    return 0;
}       
