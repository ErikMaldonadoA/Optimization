// OPTIMIZACION


#include <iostream>
#include <math.h>
#include <time.h>
using namespace std;


// Inicio del programa

int main ()
{
    
    long double s, s1, t, deltas, es, es1, deltae, alpha, k;
    
    
    srand(time(0));
    t=1000000;
    k=0.999;
    s=(0+rand()%100);
    s=s/100;
 
    
    float range=(1e-2+1e-2);
        
            
    
    while(t>10)
    {
        
                
       deltas=-1e-5+(range*rand()/RAND_MAX);
       
         
        s1=s+deltas;
        if (s1>0 && s1<1){
  
        es=0.5 + 0.3* sin(2*3.1416*s)+ 0.15*cos(21*3.1416*s);
        es1=0.5 + 0.3* sin(2*3.1416*s1)+ 0.15*cos(21*3.1416*s1);
        
        deltae=es1-es;
        
        if (deltae<=0){
        s=s1;
        }
        else{
        alpha=(0+rand()%100);
        alpha=alpha/100;
              
        if (alpha<=exp(-deltae/t))
             s=s1;
         }
        
        t=t*k;
        k=k*0.99;
        }
        
        
       
        
    }
    
    
    
    cout<<"El valor de X = "<<s<<" y el valor de Y = "<<es<<endl;
    
    //Para mantener la ventana abierta 
    cin.ignore (256,'\n');
    cout << "Presione ENTER para terminar" << endl;
    cin.get();
    
    return 0;
}       
